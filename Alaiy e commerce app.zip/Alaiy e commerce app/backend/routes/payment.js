const express = require('express');
const Stripe = require('stripe');
const router = express.Router();
const stripe = Stripe(process.env.STRIPE_SECRET);

router.post('/checkout', async (req, res) => {
  const { amount, token } = req.body;
  try {
    const charge = await stripe.charges.create({
      amount: Math.round(amount * 100), // Stripe expects cents
      currency: 'usd',
      source: token.id,
      description: 'Handicraft Toy Purchase',
    });
    res.json(charge);
  } catch (err) {
    res.status(500).send(err);
  }
});

module.exports = router;