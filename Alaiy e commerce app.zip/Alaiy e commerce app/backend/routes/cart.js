const express = require('express');
const User = require('../models/User');
const Product = require('../models/Product');
const jwt = require('jsonwebtoken');
const router = express.Router();

function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: "No token" });
  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ error: "Invalid token" });
    req.userId = decoded.id;
    next();
  });
}

// Get cart
router.get('/', auth, async (req, res) => {
  const user = await User.findById(req.userId).populate('cart');
  res.json(user.cart || []);
});

// Add to cart
router.post('/add', auth, async (req, res) => {
  const { productId } = req.body;
  const user = await User.findById(req.userId);
  if (!user.cart.includes(productId)) user.cart.push(productId);
  await user.save();
  res.json(user.cart);
});

// Remove from cart
router.post('/remove', auth, async (req, res) => {
  const { productId } = req.body;
  const user = await User.findById(req.userId);
  user.cart = user.cart.filter(id => id.toString() !== productId);
  await user.save();
  res.json(user.cart);
});

// Clear cart
router.post('/clear', auth, async (req, res) => {
  const user = await User.findById(req.userId);
  user.cart = [];
  await user.save();
  res.json(user.cart);
});

module.exports = router;