const express = require('express');
const Product = require('../models/Product');
const router = express.Router();

// Get products (with optional category and search)
router.get('/', async (req, res) => {
  const { category, search } = req.query;
  let query = {};
  if (category) query.category = category;
  if (search) query.name = { $regex: search, $options: 'i' };
  const products = await Product.find(query);
  res.json(products);
});

// Add products (for admin/demo - you can seed using POST)
router.post('/', async (req, res) => {
  const prod = await Product.create(req.body);
  res.json(prod);
});

module.exports = router;