module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        vintage: '#F5E6C5',
        retro: '#CC3363',
        'retro-dark': '#8A194D',
      },
      fontFamily: {
        funky: ['"Bangers"', 'cursive'],
      },
    },
  },
  plugins: [],
}