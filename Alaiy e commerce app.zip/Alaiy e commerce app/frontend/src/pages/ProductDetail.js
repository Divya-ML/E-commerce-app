import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useCart } from '../context/CartContext';

function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const { addToCart } = useCart();

  useEffect(() => {
    axios.get(`http://localhost:5000/api/products?search=${id}`).then(res => {
      setProduct(res.data[0]);
    });
  }, [id]);

  if (!product) return <div>Loading...</div>;

  return (
    <div className="bg-vintage min-h-screen flex flex-col items-center py-8">
      <img src={product.image} alt={product.name} className="h-48 w-48 object-cover rounded mb-6" />
      <h2 className="text-retro text-3xl mb-2">{product.name}</h2>
      <p className="mb-4">{product.description}</p>
      <div className="text-xl font-bold mb-4">${product.price}</div>
      <button onClick={() => addToCart(product._id)} className="bg-retro text-white px-6 py-2 rounded">Add to Cart</button>
    </div>
  );
}

export default ProductDetail;