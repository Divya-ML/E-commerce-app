import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { loadStripe } from '@stripe/stripe-js';
import axios from 'axios';

const stripePromise = loadStripe('pk_test_XXXXXXXXXXXXXXXXXXXXXXXX');

function Checkout() {
  const { cart, clearCart } = useCart();
  const [email, setEmail] = useState('');
  const [cardToken, setCardToken] = useState(null);
  const [message, setMessage] = useState('');

  const total = cart.reduce((sum, prod) => sum + prod.price, 0);

  const handlePayment = async () => {
    if (!cardToken) {
      setMessage('Stripe token required');
      return;
    }
    try {
      const res = await axios.post('http://localhost:5000/api/payment/checkout', {
        amount: total,
        token: cardToken
      });
      setMessage('Payment Successful! Order Confirmed.');
      clearCart();
    } catch (e) {
      setMessage('Payment failed');
    }
  };

  // This is a simplified placeholder for Stripe Card Entry
  // For real use, embed Stripe Elements component here and set cardToken

  return (
    <div className="bg-vintage min-h-screen px-8 py-8">
      <h2 className="text-3xl text-retro font-funky mb-6">Checkout</h2>
      <div className="mb-4">
        <label className="block mb-2">Email:</label>
        <input value={email} onChange={e => setEmail(e.target.value)} className="border px-3 py-2 rounded w-1/2" />
      </div>
      {/* Replace this with Stripe Elements for real card input */}
      <div className="mb-4">
        <button onClick={() => setCardToken({id: 'tok_visa'})} className="bg-retro text-white px-4 py-2 rounded">Simulate Card Entry (Test)</button>
      </div>
      <div className="mb-4 text-xl">Total: ${total.toFixed(2)}</div>
      <button onClick={handlePayment} className="bg-retro text-white px-6 py-2 rounded">Pay</button>
      {message && <div className="mt-4 text-lg">{message}</div>}
    </div>
  );
}

export default Checkout;