import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

function Signup() {
  const { signup } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  const navigate = useNavigate();

  const handleSignup = async () => {
    try {
      await signup(email, password);
      navigate('/login');
    } catch (e) {
      setMsg('Signup failed');
    }
  };

  return (
    <div className="bg-vintage min-h-screen flex flex-col items-center justify-center">
      <h2 className="text-retro text-3xl mb-6">Signup</h2>
      <input placeholder="Email" className="border px-3 py-2 rounded mb-3" value={email} onChange={e => setEmail(e.target.value)} />
      <input placeholder="Password" type="password" className="border px-3 py-2 rounded mb-3" value={password} onChange={e => setPassword(e.target.value)} />
      <button onClick={handleSignup} className="bg-retro text-white px-6 py-2 rounded">Signup</button>
      {msg && <div className="mt-3 text-red-500">{msg}</div>}
    </div>
  );
}

export default Signup;