import React from 'react';
import { useCart } from '../context/CartContext';
import { useNavigate } from 'react-router-dom';

function Cart() {
  const { cart, removeFromCart, clearCart } = useCart();
  const navigate = useNavigate();

  const total = cart.reduce((sum, prod) => sum + prod.price, 0);

  return (
    <div className="bg-vintage min-h-screen px-8 py-8">
      <h2 className="text-3xl text-retro font-funky mb-6">Your Cart</h2>
      {cart.length === 0 ? (
        <div className="text-xl">Cart is empty.</div>
      ) : (
        <>
          <ul>
            {cart.map(prod => (
              <li key={prod._id} className="mb-4 flex items-center justify-between">
                <span>{prod.name} - ${prod.price}</span>
                <button onClick={() => removeFromCart(prod._id)} className="bg-retro text-white px-2 py-1 rounded">Remove</button>
              </li>
            ))}
          </ul>
          <div className="mt-6 text-xl">Total: ${total.toFixed(2)}</div>
          <button onClick={() => navigate('/checkout')} className="bg-retro text-white px-6 py-2 rounded mt-4">Checkout</button>
          <button onClick={() => clearCart()} className="bg-retro-dark text-white px-6 py-2 rounded mt-4 ml-2">Clear Cart</button>
        </>
      )}
    </div>
  );
}

export default Cart;