import React, { createContext, useState, useContext, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';

const CartContext = createContext();

export function CartProvider({ children }) {
  const { token } = useAuth();
  const [cart, setCart] = useState([]);

  useEffect(() => {
    if (token) {
      axios.get('http://localhost:5000/api/cart', { headers: { Authorization: `Bearer ${token}` } })
        .then(res => setCart(res.data));
    }
  }, [token]);

  const addToCart = async (productId) => {
    const res = await axios.post('http://localhost:5000/api/cart/add', { productId }, { headers: { Authorization: `Bearer ${token}` } });
    setCart(res.data);
  };

  const removeFromCart = async (productId) => {
    const res = await axios.post('http://localhost:5000/api/cart/remove', { productId }, { headers: { Authorization: `Bearer ${token}` } });
    setCart(res.data);
  };

  const clearCart = async () => {
    const res = await axios.post('http://localhost:5000/api/cart/clear', {}, { headers: { Authorization: `Bearer ${token}` } });
    setCart(res.data);
  };

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, clearCart }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);