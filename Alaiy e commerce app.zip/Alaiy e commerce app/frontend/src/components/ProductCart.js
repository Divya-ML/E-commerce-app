import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ProductCard from '../components/ProductCard';

const categories = ['All', 'Animals', 'Dolls', 'Vehicles'];

function Home() {
  const [products, setProducts] = useState([]);
  const [cat, setCat] = useState('All');
  const [search, setSearch] = useState('');

  useEffect(() => {
    let url = 'http://localhost:5000/api/products?';
    if (cat !== 'All') url += `category=${cat}&`;
    if (search) url += `search=${search}`;
    axios.get(url).then(res => setProducts(res.data));
  }, [cat, search]);

  return (
    <div className="bg-vintage min-h-screen py-6">
      <h1 className="text-retro font-funky text-4xl text-center mb-8">Handicraft Toys</h1>
      <div className="flex justify-center space-x-4 mb-6">
        {categories.map(c => (
          <button key={c} onClick={() => setCat(c)} className={`px-4 py-2 rounded ${cat === c ? 'bg-retro text-white' : 'bg-vintage border-retro border'}`}>
            {c}
          </button>
        ))}
      </div>
      <input className="block mx-auto mb-6 px-4 py-2 border rounded w-1/2" placeholder="Search toys..." value={search} onChange={e => setSearch(e.target.value)} />
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 px-10">
        {products.map(product => <ProductCard key={product._id} product={product} />)}
      </div>
    </div>
  );
}

export default Home;